/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['anenueywhdfbfmxfzfwn.supabase.co'],
  },
};

module.exports = nextConfig;
